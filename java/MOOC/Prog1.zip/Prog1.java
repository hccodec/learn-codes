public class Prog1
{
   public static void main(String args[])
    {
/*****************FOUND*****************/
     int  sum=0,n;//��ǰ��int  sum=0;
     for (n=1;n<=100;n++)
       {
/*****************FOUND*****************/
          sum=0;//��ǰ��sum=sum;
          for(int k=1;k<n;k++)
          {
 /*****************FOUND*****************/
             if(n%k==0)//��ǰ��if(n/k==0)
             sum+=k;
         }
 /*****************FOUND*****************/
         if(sum==n)//��ǰ��if(sum=n)
            System.out.print(n+"\t");
        }
    }
}