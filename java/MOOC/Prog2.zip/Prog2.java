public class Prog2
{
  public static void main(String args[])
    { int i,j;
       /***********FOUND***********/
      for (i=1;i<=5;i++)//��ǰ��for (i=1;i<5;i++)
        {
         for(j=1;j<=5-i;j++)
           System.out.print("  ");
         for (j=1;j<i;j++)
          /***********FOUND***********/
           System.out.print(j+" ");//��ǰ��System.out.print(i+" ");
          /***********FOUND***********/
         for (j=i;j>=1;j--)//��ǰ��for (j=i;j>1;j--)
           System.out.print(j+" ");
           /***********FOUND***********/
         System.out.println();//��ǰ��System.out.print();
        }
    }
}