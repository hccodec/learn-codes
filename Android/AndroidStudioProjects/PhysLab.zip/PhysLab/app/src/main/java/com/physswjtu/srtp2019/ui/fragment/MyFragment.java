/*
 * Copyright (c) 2019. 西南交大应用物理系韩宝佳
 */

package com.physswjtu.srtp2019.ui.fragment;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * 由 84697 创建
 * 日期为 2019/7/7
 * 工程 PhysLab
 */
public abstract class MyFragment extends Fragment {
    public abstract void update(@Nullable Object... objects);
}
