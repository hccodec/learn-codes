/*
 * Copyright (c) 2019. 西南交大应用物理系韩宝佳
 */

package com.physswjtu.srtp2019.data;

/**
 * 由 84697 创建
 * 日期为 2019/7/29
 * 工程 PhysLab
 */
public class TempData {
    /*
        public static final String TAG = "TempData: ";
        public static final String ERROR = "hbj-error";

        /**********************Map集合全局传递数据**************************/
/*    public static final String TAG_outputX = "outputX";
    public static final String TAG_outputY = "outputY";
    public static final String TAG_usrId = "usrName";
    public static final String TAG_usrType = "usrType";

    public static final String KEY_IS_SILENT = "isSilent";
    public static final String KEY_DEV_DATA_SOURCE = "dataSource";

    public static final String KEY_DEV_DATA_SOURCE_LOCAL = "本地";
    public static final String KEY_DEV_DATA_SOURCE_SERVER = "云端";

    public static final String KEY_SERVER_ADDRESS = "server";
    public static final String KEY_SERVER_ADDRESS_CURRENT = "http://y96vrw.natappfree.cc";


    public static final String KEY_PIC_SIZE_WIDTH = "outputX";
    public static final String KEY_PIC_SIZE_HEIGHT = "outputY";
    //******************************设置项******************************/
/*
    public static HashMap<String, Object> map = new HashMap<>();

    // 存放数据
    public static void putData(String key, Object value) {
        Log.d("hbj", TAG + key + ": " + value);
        map.put(key, value);
        Log.d("hbj", MessageFormat.format(TAG + "key是：{0}，value是：{1}", key, map.get(key)));
    }

    //获取数据
    public static String getString(String key) {
        return getString(key, ERROR);
    }

    //获取数据
    public static String getString(String key, String defValue) {
        Log.d("hbj", "TempData: getData(): " + map.get(key));
        if (map.get(key) != null)
            return (String) map.get(key);
        return defValue;
    }

    //获取数据
    public static boolean getBoolean(String key, boolean defValue) {
        Log.d("hbj", "TempData: getData(): " + map.get(key));
        if (map.get(key) != null)
            return (boolean) map.get(key);
        return defValue;
    }

    //获取数据
    public static int getInt(String key, int defValue) {
        Log.d("hbj", "TempData: getData(): " + map.get(key));
        if (map.get(key) != null)
            return (int) map.get(key);
        return -1;
    }

    //获取数据
    public static int getInt(String key) {
        return getInt(key, -1);
    }

    //删除数据
    public static Object delData(String key) {
        Log.d("hbj", TAG + key + "被删掉了……");
        return map.remove(key);
    }

    public static void wipeData(String key) {
        map.clear();
    }
*/
}
