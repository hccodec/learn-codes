import React from 'react'
import ReactDOM from 'react-dom'
import {MyTable} from '@/component/MyTable'

ReactDOM.render(
    <div>
        <MyTable />
    </div>,
    document.getElementById('app'))