﻿namespace WindowsTest
{
    partial class winMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            TX.Framework.WindowUI.Controls.RangeValueHeader rangeValueHeader1 = new TX.Framework.WindowUI.Controls.RangeValueHeader();
            TX.Framework.WindowUI.Controls.Docking.DockPanelSkin dockPanelSkin1 = new TX.Framework.WindowUI.Controls.Docking.DockPanelSkin();
            TX.Framework.WindowUI.Controls.Docking.AutoHideStripSkin autoHideStripSkin1 = new TX.Framework.WindowUI.Controls.Docking.AutoHideStripSkin();
            TX.Framework.WindowUI.Controls.Docking.DockPanelGradient dockPanelGradient1 = new TX.Framework.WindowUI.Controls.Docking.DockPanelGradient();
            TX.Framework.WindowUI.Controls.Docking.TabGradient tabGradient1 = new TX.Framework.WindowUI.Controls.Docking.TabGradient();
            TX.Framework.WindowUI.Controls.Docking.DockPaneStripSkin dockPaneStripSkin1 = new TX.Framework.WindowUI.Controls.Docking.DockPaneStripSkin();
            TX.Framework.WindowUI.Controls.Docking.DockPaneStripGradient dockPaneStripGradient1 = new TX.Framework.WindowUI.Controls.Docking.DockPaneStripGradient();
            TX.Framework.WindowUI.Controls.Docking.TabGradient tabGradient2 = new TX.Framework.WindowUI.Controls.Docking.TabGradient();
            TX.Framework.WindowUI.Controls.Docking.DockPanelGradient dockPanelGradient2 = new TX.Framework.WindowUI.Controls.Docking.DockPanelGradient();
            TX.Framework.WindowUI.Controls.Docking.TabGradient tabGradient3 = new TX.Framework.WindowUI.Controls.Docking.TabGradient();
            TX.Framework.WindowUI.Controls.Docking.DockPaneStripToolWindowGradient dockPaneStripToolWindowGradient1 = new TX.Framework.WindowUI.Controls.Docking.DockPaneStripToolWindowGradient();
            TX.Framework.WindowUI.Controls.Docking.TabGradient tabGradient4 = new TX.Framework.WindowUI.Controls.Docking.TabGradient();
            TX.Framework.WindowUI.Controls.Docking.TabGradient tabGradient5 = new TX.Framework.WindowUI.Controls.Docking.TabGradient();
            TX.Framework.WindowUI.Controls.Docking.DockPanelGradient dockPanelGradient3 = new TX.Framework.WindowUI.Controls.Docking.DockPanelGradient();
            TX.Framework.WindowUI.Controls.Docking.TabGradient tabGradient6 = new TX.Framework.WindowUI.Controls.Docking.TabGradient();
            TX.Framework.WindowUI.Controls.Docking.TabGradient tabGradient7 = new TX.Framework.WindowUI.Controls.Docking.TabGradient();
            TX.Framework.WindowUI.Controls.CheckBoxProperties checkBoxProperties1 = new TX.Framework.WindowUI.Controls.CheckBoxProperties();
            TX.Framework.WindowUI.Controls.TreeListViewItemCollection.TreeListViewItemCollectionComparer treeListViewItemCollectionComparer1 = new TX.Framework.WindowUI.Controls.TreeListViewItemCollection.TreeListViewItemCollectionComparer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.xPanderPanelList1 = new TX.Framework.WindowUI.Controls.XPanderPanelList();
            this.xPanderPanel1 = new TX.Framework.WindowUI.Controls.XPanderPanel();
            this.txTreeComboBox2 = new TX.Framework.WindowUI.Controls.TXTreeComboBox();
            this.txTextBox2 = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.txButton10 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txTextBox1 = new TX.Framework.WindowUI.Controls.TXTextBox();
            this.xPanderPanel2 = new TX.Framework.WindowUI.Controls.XPanderPanel();
            this.xPanderPanel3 = new TX.Framework.WindowUI.Controls.XPanderPanel();
            this.xPanderPanel4 = new TX.Framework.WindowUI.Controls.XPanderPanel();
            this.txTabControl1 = new TX.Framework.WindowUI.Controls.TXTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txHtmlEditor1 = new TX.Framework.WindowUI.Controls.TXHtmlEditor();
            this.txGroupBox1 = new TX.Framework.WindowUI.Controls.TXGroupBox();
            this.txDateTimePicker1 = new TX.Framework.WindowUI.Controls.TXDateTimePicker();
            this.txRadioButton2 = new TX.Framework.WindowUI.Controls.TXRadioButton();
            this.txRadioButton1 = new TX.Framework.WindowUI.Controls.TXRadioButton();
            this.txCheckBox2 = new TX.Framework.WindowUI.Controls.TXCheckBox();
            this.txComboBox1 = new TX.Framework.WindowUI.Controls.TXComboBox();
            this.txCheckBox1 = new TX.Framework.WindowUI.Controls.TXCheckBox();
            this.txButton9 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton8 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton7 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton6 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton5 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton4 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton3 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton2 = new TX.Framework.WindowUI.Controls.TXButton();
            this.txButton1 = new TX.Framework.WindowUI.Controls.TXButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel4 = new TX.Framework.WindowUI.Controls.Panel();
            this.txRangeValue1 = new TX.Framework.WindowUI.Controls.TXRangeValue();
            this.panel3 = new TX.Framework.WindowUI.Controls.Panel();
            this.dockPanel1 = new TX.Framework.WindowUI.Controls.Docking.DockPanel();
            this.panel2 = new TX.Framework.WindowUI.Controls.Panel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.multiselectComboBox1 = new TX.Framework.WindowUI.Controls.MultiselectComboBox();
            this.txTreeComboBox1 = new TX.Framework.WindowUI.Controls.TXTreeComboBox();
            this.txMenuStrip1 = new TX.Framework.WindowUI.Controls.TXMenuStrip();
            this.txMenuStrip2 = new TX.Framework.WindowUI.Controls.TXMenuStrip();
            this.右键菜单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.好好学习ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.天天向上ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.treeListView1 = new TX.Framework.WindowUI.Controls.TreeListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.monthCalendar1 = new TX.Framework.WindowUI.Controls.MonthCalendar();
            this.txGroupBox2 = new TX.Framework.WindowUI.Controls.TXGroupBox();
            this.txDateTimePicker2 = new TX.Framework.WindowUI.Controls.TXDateTimePicker();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.xPanderPanelList1.SuspendLayout();
            this.xPanderPanel1.SuspendLayout();
            this.txTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.txGroupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.txMenuStrip2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.txGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.splitContainer1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(8, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(962, 552);
            this.panel1.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.xPanderPanelList1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.txTabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(962, 552);
            this.splitContainer1.SplitterDistance = 237;
            this.splitContainer1.TabIndex = 0;
            // 
            // xPanderPanelList1
            // 
            this.xPanderPanelList1.CaptionStyle = TX.Framework.WindowUI.Controls.CaptionStyle.Normal;
            this.xPanderPanelList1.Controls.Add(this.xPanderPanel1);
            this.xPanderPanelList1.Controls.Add(this.xPanderPanel2);
            this.xPanderPanelList1.Controls.Add(this.xPanderPanel3);
            this.xPanderPanelList1.Controls.Add(this.xPanderPanel4);
            this.xPanderPanelList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xPanderPanelList1.GradientBackground = System.Drawing.Color.Empty;
            this.xPanderPanelList1.Location = new System.Drawing.Point(0, 0);
            this.xPanderPanelList1.Name = "xPanderPanelList1";
            this.xPanderPanelList1.PanelColors = null;
            this.xPanderPanelList1.PanelStyle = TX.Framework.WindowUI.Controls.PanelStyle.Office2007;
            this.xPanderPanelList1.ShowExpandIcon = true;
            this.xPanderPanelList1.Size = new System.Drawing.Size(237, 552);
            this.xPanderPanelList1.TabIndex = 0;
            this.xPanderPanelList1.Text = "xPanderPanelList1";
            // 
            // xPanderPanel1
            // 
            this.xPanderPanel1.CaptionFont = new System.Drawing.Font("Microsoft YaHei UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.xPanderPanel1.Controls.Add(this.txTreeComboBox2);
            this.xPanderPanel1.Controls.Add(this.txTextBox2);
            this.xPanderPanel1.Controls.Add(this.txButton10);
            this.xPanderPanel1.Controls.Add(this.txTextBox1);
            this.xPanderPanel1.CustomColors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.xPanderPanel1.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.xPanderPanel1.CustomColors.CaptionCheckedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionCheckedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionCheckedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.xPanderPanel1.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel1.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel1.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel1.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel1.CustomColors.CaptionPressedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionPressedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionPressedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionSelectedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel1.CustomColors.CaptionSelectedText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel1.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel1.CustomColors.FlatCaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel1.CustomColors.FlatCaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel1.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.xPanderPanel1.Expand = true;
            this.xPanderPanel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel1.Image = null;
            this.xPanderPanel1.Name = "xPanderPanel1";
            this.xPanderPanel1.PanelStyle = TX.Framework.WindowUI.Controls.PanelStyle.Office2007;
            this.xPanderPanel1.Size = new System.Drawing.Size(237, 477);
            this.xPanderPanel1.TabIndex = 0;
            this.xPanderPanel1.Text = "分组1";
            this.xPanderPanel1.ToolTipTextCloseIcon = null;
            this.xPanderPanel1.ToolTipTextExpandIconPanelCollapsed = null;
            this.xPanderPanel1.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // txTreeComboBox2
            // 
            this.txTreeComboBox2.CheckBox = false;
            this.txTreeComboBox2.CheckedValues = null;
            this.txTreeComboBox2.DefaultNodeText = "";
            this.txTreeComboBox2.DoubleSelecteEnable = true;
            this.txTreeComboBox2.FormattingEnabled = true;
            this.txTreeComboBox2.IsInsertDefaultNode = true;
            this.txTreeComboBox2.Location = new System.Drawing.Point(20, 269);
            this.txTreeComboBox2.MultiLevelDataSourceMember = "";
            this.txTreeComboBox2.Name = "txTreeComboBox2";
            this.txTreeComboBox2.PathSeparator = " ";
            this.txTreeComboBox2.SelectedNode = null;
            this.txTreeComboBox2.SelectedValue = "";
            this.txTreeComboBox2.ShowFullPathText = true;
            this.txTreeComboBox2.Size = new System.Drawing.Size(164, 20);
            this.txTreeComboBox2.TabIndex = 3;
            this.txTreeComboBox2.TreeMaxDegree = 0;
            // 
            // txTextBox2
            // 
            this.txTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.txTextBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txTextBox2.CornerRadius = 0;
            this.txTextBox2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txTextBox2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txTextBox2.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTextBox2.Image = null;
            this.txTextBox2.ImageSize = new System.Drawing.Size(0, 0);
            this.txTextBox2.Location = new System.Drawing.Point(4, 94);
            this.txTextBox2.Name = "txTextBox2";
            this.txTextBox2.Padding = new System.Windows.Forms.Padding(2);
            this.txTextBox2.PasswordChar = '\0';
            this.txTextBox2.Required = false;
            this.txTextBox2.Size = new System.Drawing.Size(180, 30);
            this.txTextBox2.TabIndex = 2;
            this.txTextBox2.Text = "123";
            // 
            // txButton10
            // 
            this.txButton10.Image = null;
            this.txButton10.Location = new System.Drawing.Point(93, 183);
            this.txButton10.Name = "txButton10";
            this.txButton10.Size = new System.Drawing.Size(82, 28);
            this.txButton10.TabIndex = 1;
            this.txButton10.Text = "txButton10";
            this.txButton10.UseVisualStyleBackColor = true;
            // 
            // txTextBox1
            // 
            this.txTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.txTextBox1.BorderColor = System.Drawing.Color.Red;
            this.txTextBox1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txTextBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txTextBox1.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTextBox1.Image = null;
            this.txTextBox1.ImageSize = new System.Drawing.Size(0, 0);
            this.txTextBox1.Location = new System.Drawing.Point(4, 51);
            this.txTextBox1.Name = "txTextBox1";
            this.txTextBox1.Padding = new System.Windows.Forms.Padding(2);
            this.txTextBox1.PasswordChar = '\0';
            this.txTextBox1.Required = false;
            this.txTextBox1.Size = new System.Drawing.Size(180, 22);
            this.txTextBox1.TabIndex = 0;
            this.txTextBox1.Text = "123";
            // 
            // xPanderPanel2
            // 
            this.xPanderPanel2.CaptionFont = new System.Drawing.Font("Microsoft YaHei UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.xPanderPanel2.CustomColors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.xPanderPanel2.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.xPanderPanel2.CustomColors.CaptionCheckedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionCheckedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionCheckedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.xPanderPanel2.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel2.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel2.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel2.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel2.CustomColors.CaptionPressedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionPressedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionPressedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionSelectedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel2.CustomColors.CaptionSelectedText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel2.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel2.CustomColors.FlatCaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel2.CustomColors.FlatCaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel2.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.xPanderPanel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel2.Image = null;
            this.xPanderPanel2.Name = "xPanderPanel2";
            this.xPanderPanel2.PanelStyle = TX.Framework.WindowUI.Controls.PanelStyle.Office2007;
            this.xPanderPanel2.Size = new System.Drawing.Size(237, 25);
            this.xPanderPanel2.TabIndex = 1;
            this.xPanderPanel2.Text = "xPanderPanel2";
            this.xPanderPanel2.ToolTipTextCloseIcon = null;
            this.xPanderPanel2.ToolTipTextExpandIconPanelCollapsed = null;
            this.xPanderPanel2.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // xPanderPanel3
            // 
            this.xPanderPanel3.CaptionFont = new System.Drawing.Font("Microsoft YaHei UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.xPanderPanel3.CustomColors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.xPanderPanel3.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.xPanderPanel3.CustomColors.CaptionCheckedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionCheckedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionCheckedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.xPanderPanel3.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel3.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel3.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel3.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel3.CustomColors.CaptionPressedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionPressedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionPressedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionSelectedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel3.CustomColors.CaptionSelectedText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel3.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel3.CustomColors.FlatCaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel3.CustomColors.FlatCaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel3.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.xPanderPanel3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel3.Image = null;
            this.xPanderPanel3.Name = "xPanderPanel3";
            this.xPanderPanel3.PanelStyle = TX.Framework.WindowUI.Controls.PanelStyle.Office2007;
            this.xPanderPanel3.Size = new System.Drawing.Size(237, 25);
            this.xPanderPanel3.TabIndex = 2;
            this.xPanderPanel3.Text = "xPanderPanel3";
            this.xPanderPanel3.ToolTipTextCloseIcon = null;
            this.xPanderPanel3.ToolTipTextExpandIconPanelCollapsed = null;
            this.xPanderPanel3.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // xPanderPanel4
            // 
            this.xPanderPanel4.CaptionFont = new System.Drawing.Font("Microsoft YaHei UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.xPanderPanel4.CustomColors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.xPanderPanel4.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.xPanderPanel4.CustomColors.CaptionCheckedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionCheckedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionCheckedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.xPanderPanel4.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel4.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel4.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.xPanderPanel4.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel4.CustomColors.CaptionPressedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionPressedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionPressedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionSelectedGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.xPanderPanel4.CustomColors.CaptionSelectedText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel4.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel4.CustomColors.FlatCaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel4.CustomColors.FlatCaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.xPanderPanel4.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.xPanderPanel4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.xPanderPanel4.Image = null;
            this.xPanderPanel4.Name = "xPanderPanel4";
            this.xPanderPanel4.PanelStyle = TX.Framework.WindowUI.Controls.PanelStyle.Office2007;
            this.xPanderPanel4.Size = new System.Drawing.Size(237, 25);
            this.xPanderPanel4.TabIndex = 3;
            this.xPanderPanel4.Text = "xPanderPanel4";
            this.xPanderPanel4.ToolTipTextCloseIcon = null;
            this.xPanderPanel4.ToolTipTextExpandIconPanelCollapsed = null;
            this.xPanderPanel4.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // txTabControl1
            // 
            this.txTabControl1.BaseTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.txTabControl1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txTabControl1.CaptionFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txTabControl1.CheckedTabColor = System.Drawing.Color.Lime;
            this.txTabControl1.Controls.Add(this.tabPage1);
            this.txTabControl1.Controls.Add(this.tabPage2);
            this.txTabControl1.Controls.Add(this.tabPage3);
            this.txTabControl1.Controls.Add(this.tabPage4);
            this.txTabControl1.Controls.Add(this.tabPage5);
            this.txTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txTabControl1.HeightLightTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txTabControl1.Location = new System.Drawing.Point(0, 0);
            this.txTabControl1.Name = "txTabControl1";
            this.txTabControl1.SelectedIndex = 0;
            this.txTabControl1.Size = new System.Drawing.Size(721, 552);
            this.txTabControl1.TabCornerRadius = 3;
            this.txTabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txGroupBox2);
            this.tabPage1.Controls.Add(this.txHtmlEditor1);
            this.tabPage1.Controls.Add(this.txGroupBox1);
            this.tabPage1.Controls.Add(this.txRadioButton2);
            this.tabPage1.Controls.Add(this.txRadioButton1);
            this.tabPage1.Controls.Add(this.txCheckBox2);
            this.tabPage1.Controls.Add(this.txComboBox1);
            this.tabPage1.Controls.Add(this.txCheckBox1);
            this.tabPage1.Controls.Add(this.txButton9);
            this.tabPage1.Controls.Add(this.txButton8);
            this.tabPage1.Controls.Add(this.txButton7);
            this.tabPage1.Controls.Add(this.txButton6);
            this.tabPage1.Controls.Add(this.txButton5);
            this.tabPage1.Controls.Add(this.txButton4);
            this.tabPage1.Controls.Add(this.txButton3);
            this.tabPage1.Controls.Add(this.txButton2);
            this.tabPage1.Controls.Add(this.txButton1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(713, 519);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "窗体组件测试";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txHtmlEditor1
            // 
            this.txHtmlEditor1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.txHtmlEditor1.HeightLightBolorColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.txHtmlEditor1.Location = new System.Drawing.Point(35, 342);
            this.txHtmlEditor1.Name = "txHtmlEditor1";
            this.txHtmlEditor1.Padding = new System.Windows.Forms.Padding(3);
            this.txHtmlEditor1.Size = new System.Drawing.Size(596, 131);
            this.txHtmlEditor1.TabIndex = 15;
            // 
            // txGroupBox1
            // 
            this.txGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.txGroupBox1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txGroupBox1.BorderStyle = TX.Framework.WindowUI.EnumBorderStyle.QQStyle;
            this.txGroupBox1.CaptionColor = System.Drawing.Color.Black;
            this.txGroupBox1.CaptionFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.txGroupBox1.Controls.Add(this.txDateTimePicker1);
            this.txGroupBox1.Location = new System.Drawing.Point(35, 240);
            this.txGroupBox1.Name = "txGroupBox1";
            this.txGroupBox1.Size = new System.Drawing.Size(270, 70);
            this.txGroupBox1.TabIndex = 14;
            this.txGroupBox1.TabStop = false;
            this.txGroupBox1.Text = "分组1";
            this.txGroupBox1.TextMargin = 6;
            // 
            // txDateTimePicker1
            // 
            this.txDateTimePicker1.CalendarForeColor = System.Drawing.Color.Blue;
            this.txDateTimePicker1.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.txDateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(74)))), ((int)(((byte)(181)))), ((int)(((byte)(237)))));
            this.txDateTimePicker1.CalendarTrailingForeColor = System.Drawing.Color.CadetBlue;
            this.txDateTimePicker1.Location = new System.Drawing.Point(7, 20);
            this.txDateTimePicker1.Name = "txDateTimePicker1";
            this.txDateTimePicker1.ShowCheckBox = true;
            this.txDateTimePicker1.Size = new System.Drawing.Size(132, 21);
            this.txDateTimePicker1.TabIndex = 0;
            this.txDateTimePicker1.Value = new System.DateTime(2015, 8, 9, 16, 8, 2, 250);
            // 
            // txRadioButton2
            // 
            this.txRadioButton2.AutoSize = true;
            this.txRadioButton2.Location = new System.Drawing.Point(196, 198);
            this.txRadioButton2.MaxRadius = 8;
            this.txRadioButton2.MinimumSize = new System.Drawing.Size(22, 22);
            this.txRadioButton2.MinRadius = 4;
            this.txRadioButton2.Name = "txRadioButton2";
            this.txRadioButton2.Size = new System.Drawing.Size(35, 22);
            this.txRadioButton2.TabIndex = 13;
            this.txRadioButton2.TabStop = true;
            this.txRadioButton2.Text = "女";
            this.txRadioButton2.UseVisualStyleBackColor = true;
            // 
            // txRadioButton1
            // 
            this.txRadioButton1.AutoSize = true;
            this.txRadioButton1.Location = new System.Drawing.Point(153, 199);
            this.txRadioButton1.MaxRadius = 8;
            this.txRadioButton1.MinimumSize = new System.Drawing.Size(22, 22);
            this.txRadioButton1.MinRadius = 4;
            this.txRadioButton1.Name = "txRadioButton1";
            this.txRadioButton1.Size = new System.Drawing.Size(35, 22);
            this.txRadioButton1.TabIndex = 12;
            this.txRadioButton1.TabStop = true;
            this.txRadioButton1.Text = "男";
            this.txRadioButton1.UseVisualStyleBackColor = true;
            // 
            // txCheckBox2
            // 
            this.txCheckBox2.AutoSize = true;
            this.txCheckBox2.Location = new System.Drawing.Point(84, 200);
            this.txCheckBox2.MinimumSize = new System.Drawing.Size(20, 20);
            this.txCheckBox2.Name = "txCheckBox2";
            this.txCheckBox2.Size = new System.Drawing.Size(36, 20);
            this.txCheckBox2.TabIndex = 11;
            this.txCheckBox2.Text = "女";
            this.txCheckBox2.UseVisualStyleBackColor = true;
            // 
            // txComboBox1
            // 
            this.txComboBox1.FormattingEnabled = true;
            this.txComboBox1.Items.AddRange(new object[] {
            "男",
            "女"});
            this.txComboBox1.Location = new System.Drawing.Point(245, 200);
            this.txComboBox1.Name = "txComboBox1";
            this.txComboBox1.Size = new System.Drawing.Size(150, 20);
            this.txComboBox1.TabIndex = 10;
            // 
            // txCheckBox1
            // 
            this.txCheckBox1.AutoSize = true;
            this.txCheckBox1.Location = new System.Drawing.Point(42, 200);
            this.txCheckBox1.MinimumSize = new System.Drawing.Size(20, 20);
            this.txCheckBox1.Name = "txCheckBox1";
            this.txCheckBox1.Size = new System.Drawing.Size(36, 20);
            this.txCheckBox1.TabIndex = 9;
            this.txCheckBox1.Text = "男";
            this.txCheckBox1.UseVisualStyleBackColor = true;
            // 
            // txButton9
            // 
            this.txButton9.Image = null;
            this.txButton9.Location = new System.Drawing.Point(555, 65);
            this.txButton9.Name = "txButton9";
            this.txButton9.Size = new System.Drawing.Size(106, 37);
            this.txButton9.TabIndex = 8;
            this.txButton9.Text = "List";
            this.txButton9.UseVisualStyleBackColor = true;
            this.txButton9.Click += new System.EventHandler(this.txButton9_Click);
            // 
            // txButton8
            // 
            this.txButton8.Image = null;
            this.txButton8.Location = new System.Drawing.Point(399, 127);
            this.txButton8.Name = "txButton8";
            this.txButton8.Size = new System.Drawing.Size(106, 37);
            this.txButton8.TabIndex = 7;
            this.txButton8.Text = "MessageBox-询问";
            this.txButton8.UseVisualStyleBackColor = true;
            this.txButton8.Click += new System.EventHandler(this.txButton8_Click);
            // 
            // txButton7
            // 
            this.txButton7.Image = null;
            this.txButton7.Location = new System.Drawing.Point(427, 65);
            this.txButton7.Name = "txButton7";
            this.txButton7.Size = new System.Drawing.Size(106, 37);
            this.txButton7.TabIndex = 6;
            this.txButton7.Text = "WaitingBox";
            this.txButton7.UseVisualStyleBackColor = true;
            this.txButton7.Click += new System.EventHandler(this.txButton7_Click);
            // 
            // txButton6
            // 
            this.txButton6.Image = null;
            this.txButton6.Location = new System.Drawing.Point(274, 127);
            this.txButton6.Name = "txButton6";
            this.txButton6.Size = new System.Drawing.Size(106, 37);
            this.txButton6.TabIndex = 5;
            this.txButton6.Text = "MessageBox-错误";
            this.txButton6.UseVisualStyleBackColor = true;
            this.txButton6.Click += new System.EventHandler(this.txButton6_Click);
            // 
            // txButton5
            // 
            this.txButton5.Image = null;
            this.txButton5.Location = new System.Drawing.Point(162, 127);
            this.txButton5.Name = "txButton5";
            this.txButton5.Size = new System.Drawing.Size(106, 37);
            this.txButton5.TabIndex = 4;
            this.txButton5.Text = "MessageBox-警告";
            this.txButton5.UseVisualStyleBackColor = true;
            this.txButton5.Click += new System.EventHandler(this.txButton5_Click);
            // 
            // txButton4
            // 
            this.txButton4.Image = null;
            this.txButton4.Location = new System.Drawing.Point(162, 65);
            this.txButton4.Name = "txButton4";
            this.txButton4.Size = new System.Drawing.Size(106, 37);
            this.txButton4.TabIndex = 3;
            this.txButton4.Text = "ErrorBox";
            this.txButton4.UseVisualStyleBackColor = true;
            this.txButton4.Click += new System.EventHandler(this.txButton4_Click);
            // 
            // txButton3
            // 
            this.txButton3.Image = null;
            this.txButton3.Location = new System.Drawing.Point(35, 127);
            this.txButton3.Name = "txButton3";
            this.txButton3.Size = new System.Drawing.Size(106, 37);
            this.txButton3.TabIndex = 2;
            this.txButton3.Text = "MessageBox-Info";
            this.txButton3.UseVisualStyleBackColor = true;
            this.txButton3.Click += new System.EventHandler(this.txButton3_Click);
            // 
            // txButton2
            // 
            this.txButton2.Image = null;
            this.txButton2.Location = new System.Drawing.Point(289, 65);
            this.txButton2.Name = "txButton2";
            this.txButton2.Size = new System.Drawing.Size(106, 37);
            this.txButton2.TabIndex = 1;
            this.txButton2.Text = "PopBox";
            this.txButton2.UseVisualStyleBackColor = true;
            this.txButton2.Click += new System.EventHandler(this.txButton2_Click);
            // 
            // txButton1
            // 
            this.txButton1.Image = null;
            this.txButton1.Location = new System.Drawing.Point(35, 65);
            this.txButton1.Name = "txButton1";
            this.txButton1.Size = new System.Drawing.Size(106, 37);
            this.txButton1.TabIndex = 0;
            this.txButton1.Text = "BaseForm";
            this.txButton1.UseVisualStyleBackColor = true;
            this.txButton1.Click += new System.EventHandler(this.txButton1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.dockPanel1);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(713, 519);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.AssociatedSplitter = null;
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel4.CaptionHeight = 22;
            this.panel4.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel4.Controls.Add(this.txRangeValue1);
            this.panel4.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel4.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel4.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel4.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel4.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel4.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel4.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel4.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel4.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel4.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel4.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel4.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel4.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel4.Image = null;
            this.panel4.Location = new System.Drawing.Point(203, 147);
            this.panel4.MinimumSize = new System.Drawing.Size(22, 22);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(507, 369);
            this.panel4.TabIndex = 4;
            this.panel4.Text = "panel4";
            this.panel4.ToolTipTextCloseIcon = null;
            this.panel4.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel4.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // txRangeValue1
            // 
            this.txRangeValue1.BackColor = System.Drawing.Color.Transparent;
            this.txRangeValue1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txRangeValue1.EditEnable = true;
            rangeValueHeader1.LowerValueTitle = "范围下限";
            rangeValueHeader1.UpperValueTitle = "范围上限";
            rangeValueHeader1.ValueTitle = "金额数值";
            this.txRangeValue1.Header = rangeValueHeader1;
            this.txRangeValue1.Location = new System.Drawing.Point(1, 23);
            this.txRangeValue1.Name = "txRangeValue1";
            this.txRangeValue1.RangeValues = null;
            this.txRangeValue1.Size = new System.Drawing.Size(505, 345);
            this.txRangeValue1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.AssociatedSplitter = null;
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel3.CaptionHeight = 22;
            this.panel3.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel3.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel3.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel3.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel3.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel3.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel3.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel3.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel3.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel3.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel3.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel3.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel3.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel3.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel3.Image = null;
            this.panel3.Location = new System.Drawing.Point(203, 3);
            this.panel3.MinimumSize = new System.Drawing.Size(22, 22);
            this.panel3.Name = "panel3";
            this.panel3.PanelStyle = TX.Framework.WindowUI.Controls.PanelStyle.Office2007;
            this.panel3.ShowCloseIcon = true;
            this.panel3.ShowExpandIcon = true;
            this.panel3.Size = new System.Drawing.Size(507, 144);
            this.panel3.TabIndex = 3;
            this.panel3.Text = "panel3";
            this.panel3.ToolTipTextCloseIcon = null;
            this.panel3.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel3.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // dockPanel1
            // 
            this.dockPanel1.ActiveAutoHideContent = null;
            this.dockPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dockPanel1.DockBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dockPanel1.Location = new System.Drawing.Point(203, 3);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.Size = new System.Drawing.Size(507, 513);
            dockPanelGradient1.EndColor = System.Drawing.SystemColors.ControlLight;
            dockPanelGradient1.StartColor = System.Drawing.SystemColors.ControlLight;
            autoHideStripSkin1.DockStripGradient = dockPanelGradient1;
            tabGradient1.EndColor = System.Drawing.SystemColors.Control;
            tabGradient1.StartColor = System.Drawing.SystemColors.Control;
            tabGradient1.TextColor = System.Drawing.SystemColors.ControlDarkDark;
            autoHideStripSkin1.TabGradient = tabGradient1;
            dockPanelSkin1.AutoHideStripSkin = autoHideStripSkin1;
            tabGradient2.EndColor = System.Drawing.SystemColors.ControlLightLight;
            tabGradient2.StartColor = System.Drawing.SystemColors.ControlLightLight;
            tabGradient2.TextColor = System.Drawing.SystemColors.ControlText;
            dockPaneStripGradient1.ActiveTabGradient = tabGradient2;
            dockPanelGradient2.EndColor = System.Drawing.SystemColors.Control;
            dockPanelGradient2.StartColor = System.Drawing.SystemColors.Control;
            dockPaneStripGradient1.DockStripGradient = dockPanelGradient2;
            tabGradient3.EndColor = System.Drawing.SystemColors.ControlLight;
            tabGradient3.StartColor = System.Drawing.SystemColors.ControlLight;
            tabGradient3.TextColor = System.Drawing.SystemColors.ControlText;
            dockPaneStripGradient1.InactiveTabGradient = tabGradient3;
            dockPaneStripSkin1.DocumentGradient = dockPaneStripGradient1;
            tabGradient4.EndColor = System.Drawing.SystemColors.ActiveCaption;
            tabGradient4.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            tabGradient4.StartColor = System.Drawing.SystemColors.GradientActiveCaption;
            tabGradient4.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            dockPaneStripToolWindowGradient1.ActiveCaptionGradient = tabGradient4;
            tabGradient5.EndColor = System.Drawing.SystemColors.Control;
            tabGradient5.StartColor = System.Drawing.SystemColors.Control;
            tabGradient5.TextColor = System.Drawing.SystemColors.ControlText;
            dockPaneStripToolWindowGradient1.ActiveTabGradient = tabGradient5;
            dockPanelGradient3.EndColor = System.Drawing.SystemColors.ControlLight;
            dockPanelGradient3.StartColor = System.Drawing.SystemColors.ControlLight;
            dockPaneStripToolWindowGradient1.DockStripGradient = dockPanelGradient3;
            tabGradient6.EndColor = System.Drawing.SystemColors.GradientInactiveCaption;
            tabGradient6.LinearGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            tabGradient6.StartColor = System.Drawing.SystemColors.GradientInactiveCaption;
            tabGradient6.TextColor = System.Drawing.SystemColors.ControlText;
            dockPaneStripToolWindowGradient1.InactiveCaptionGradient = tabGradient6;
            tabGradient7.EndColor = System.Drawing.Color.Transparent;
            tabGradient7.StartColor = System.Drawing.Color.Transparent;
            tabGradient7.TextColor = System.Drawing.SystemColors.ControlDarkDark;
            dockPaneStripToolWindowGradient1.InactiveTabGradient = tabGradient7;
            dockPaneStripSkin1.ToolWindowGradient = dockPaneStripToolWindowGradient1;
            dockPanelSkin1.DockPaneStripSkin = dockPaneStripSkin1;
            this.dockPanel1.Skin = dockPanelSkin1;
            this.dockPanel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.AssociatedSplitter = null;
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.CaptionFont = new System.Drawing.Font("宋体", 9.5F);
            this.panel2.CaptionHeight = 22;
            this.panel2.ColorScheme = TX.Framework.WindowUI.Controls.ColorScheme.Custom;
            this.panel2.CustomColors.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.panel2.CustomColors.CaptionCloseIcon = System.Drawing.Color.Red;
            this.panel2.CustomColors.CaptionExpandIcon = System.Drawing.SystemColors.ControlText;
            this.panel2.CustomColors.CaptionGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel2.CustomColors.CaptionGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.panel2.CustomColors.CaptionGradientMiddle = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(214)))), ((int)(((byte)(223)))));
            this.panel2.CustomColors.CaptionSelectedGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel2.CustomColors.CaptionSelectedGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(165)))), ((int)(((byte)(220)))));
            this.panel2.CustomColors.CaptionText = System.Drawing.SystemColors.ControlText;
            this.panel2.CustomColors.CollapsedCaptionText = System.Drawing.SystemColors.ControlText;
            this.panel2.CustomColors.ContentGradientBegin = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel2.CustomColors.ContentGradientEnd = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel2.CustomColors.InnerBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(218)))), ((int)(((byte)(222)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel2.Image = null;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.MinimumSize = new System.Drawing.Size(22, 22);
            this.panel2.Name = "panel2";
            this.panel2.PanelStyle = TX.Framework.WindowUI.Controls.PanelStyle.Office2007;
            this.panel2.ShowExpandIcon = true;
            this.panel2.Size = new System.Drawing.Size(200, 513);
            this.panel2.TabIndex = 0;
            this.panel2.Text = "panel2";
            this.panel2.ToolTipTextCloseIcon = null;
            this.panel2.ToolTipTextExpandIconPanelCollapsed = null;
            this.panel2.ToolTipTextExpandIconPanelExpanded = null;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.multiselectComboBox1);
            this.tabPage3.Controls.Add(this.txTreeComboBox1);
            this.tabPage3.Controls.Add(this.txMenuStrip1);
            this.tabPage3.Controls.Add(this.txMenuStrip2);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(713, 519);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // multiselectComboBox1
            // 
            checkBoxProperties1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.multiselectComboBox1.CheckBoxProperties = checkBoxProperties1;
            this.multiselectComboBox1.DisplayMemberSingleItem = "";
            this.multiselectComboBox1.FormattingEnabled = true;
            this.multiselectComboBox1.Items.AddRange(new object[] {
            "选项1",
            "选手二",
            "男",
            "女",
            "其他",
            "..."});
            this.multiselectComboBox1.Location = new System.Drawing.Point(18, 85);
            this.multiselectComboBox1.Name = "multiselectComboBox1";
            this.multiselectComboBox1.Size = new System.Drawing.Size(225, 20);
            this.multiselectComboBox1.TabIndex = 1;
            // 
            // txTreeComboBox1
            // 
            this.txTreeComboBox1.CheckBox = false;
            this.txTreeComboBox1.CheckedValues = null;
            this.txTreeComboBox1.DefaultNodeText = "";
            this.txTreeComboBox1.DoubleSelecteEnable = true;
            this.txTreeComboBox1.FormattingEnabled = true;
            this.txTreeComboBox1.IsInsertDefaultNode = true;
            this.txTreeComboBox1.Location = new System.Drawing.Point(18, 38);
            this.txTreeComboBox1.MultiLevelDataSourceMember = "";
            this.txTreeComboBox1.Name = "txTreeComboBox1";
            this.txTreeComboBox1.PathSeparator = " ";
            this.txTreeComboBox1.SelectedNode = null;
            this.txTreeComboBox1.SelectedValue = "";
            this.txTreeComboBox1.ShowFullPathText = true;
            this.txTreeComboBox1.Size = new System.Drawing.Size(225, 20);
            this.txTreeComboBox1.TabIndex = 0;
            this.txTreeComboBox1.TreeMaxDegree = 0;
            // 
            // txMenuStrip1
            // 
            this.txMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.txMenuStrip1.BeginBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.txMenuStrip1.EndBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.txMenuStrip1.Location = new System.Drawing.Point(3, 28);
            this.txMenuStrip1.Name = "txMenuStrip1";
            this.txMenuStrip1.Size = new System.Drawing.Size(707, 24);
            this.txMenuStrip1.TabIndex = 2;
            this.txMenuStrip1.Text = "txMenuStrip1";
            // 
            // txMenuStrip2
            // 
            this.txMenuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.txMenuStrip2.BeginBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.txMenuStrip2.EndBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.txMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.右键菜单ToolStripMenuItem,
            this.菜单2ToolStripMenuItem});
            this.txMenuStrip2.Location = new System.Drawing.Point(3, 3);
            this.txMenuStrip2.Name = "txMenuStrip2";
            this.txMenuStrip2.Size = new System.Drawing.Size(707, 25);
            this.txMenuStrip2.TabIndex = 3;
            this.txMenuStrip2.Text = "txMenuStrip2";
            // 
            // 右键菜单ToolStripMenuItem
            // 
            this.右键菜单ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.好好学习ToolStripMenuItem,
            this.天天向上ToolStripMenuItem,
            this.退出系统ToolStripMenuItem,
            this.关于ToolStripMenuItem});
            this.右键菜单ToolStripMenuItem.Name = "右键菜单ToolStripMenuItem";
            this.右键菜单ToolStripMenuItem.Size = new System.Drawing.Size(51, 21);
            this.右键菜单ToolStripMenuItem.Text = "菜单1";
            // 
            // 好好学习ToolStripMenuItem
            // 
            this.好好学习ToolStripMenuItem.Name = "好好学习ToolStripMenuItem";
            this.好好学习ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.好好学习ToolStripMenuItem.Text = "好好学习";
            // 
            // 天天向上ToolStripMenuItem
            // 
            this.天天向上ToolStripMenuItem.Name = "天天向上ToolStripMenuItem";
            this.天天向上ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.天天向上ToolStripMenuItem.Text = "天天向上";
            // 
            // 退出系统ToolStripMenuItem
            // 
            this.退出系统ToolStripMenuItem.Name = "退出系统ToolStripMenuItem";
            this.退出系统ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.退出系统ToolStripMenuItem.Text = "退出系统";
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.关于ToolStripMenuItem.Text = "关于";
            // 
            // 菜单2ToolStripMenuItem
            // 
            this.菜单2ToolStripMenuItem.Name = "菜单2ToolStripMenuItem";
            this.菜单2ToolStripMenuItem.Size = new System.Drawing.Size(51, 21);
            this.菜单2ToolStripMenuItem.Text = "菜单2";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.treeListView1);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(713, 519);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "List";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // treeListView1
            // 
            this.treeListView1.BackColor = System.Drawing.Color.White;
            this.treeListView1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.treeListView1.CheckBoxes = TX.Framework.WindowUI.Controls.CheckBoxesTypes.Simple;
            this.treeListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            treeListViewItemCollectionComparer1.Column = 0;
            treeListViewItemCollectionComparer1.SortOrder = System.Windows.Forms.SortOrder.Ascending;
            this.treeListView1.Comparer = treeListViewItemCollectionComparer1;
            this.treeListView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeListView1.Font = new System.Drawing.Font("宋体", 9.6F);
            this.treeListView1.HeaderBeginColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.treeListView1.HeaderEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            this.treeListView1.Location = new System.Drawing.Point(3, 3);
            this.treeListView1.Name = "treeListView1";
            this.treeListView1.OwnerDraw = true;
            this.treeListView1.RowBackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(254)))));
            this.treeListView1.RowBackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(246)))), ((int)(((byte)(253)))));
            this.treeListView1.SelectedBeginColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.treeListView1.SelectedEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(225)))), ((int)(((byte)(253)))));
            this.treeListView1.Size = new System.Drawing.Size(707, 513);
            this.treeListView1.TabIndex = 0;
            this.treeListView1.UseCompatibleStateImageBehavior = false;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 169;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Width = 133;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.monthCalendar1);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(713, 519);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.ActiveMonth.Month = 8;
            this.monthCalendar1.ActiveMonth.Year = 2015;
            this.monthCalendar1.Culture = new System.Globalization.CultureInfo("zh-CN");
            this.monthCalendar1.Footer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.monthCalendar1.Header.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.monthCalendar1.Header.TextColor = System.Drawing.Color.White;
            this.monthCalendar1.ImageList = null;
            this.monthCalendar1.Location = new System.Drawing.Point(20, 56);
            this.monthCalendar1.MaxDate = new System.DateTime(2086, 11, 15, 0, 0, 0, 0);
            this.monthCalendar1.MinDate = new System.DateTime(1986, 11, 15, 0, 0, 0, 0);
            this.monthCalendar1.Month.BackgroundImage = null;
            this.monthCalendar1.Month.BorderStyles.Normal = System.Windows.Forms.ButtonBorderStyle.Dotted;
            this.monthCalendar1.Month.BorderStyles.Selected = System.Windows.Forms.ButtonBorderStyle.Outset;
            this.monthCalendar1.Month.Colors.Days.Text = System.Drawing.Color.Red;
            this.monthCalendar1.Month.Colors.Selected.Border = System.Drawing.Color.Red;
            this.monthCalendar1.Month.Colors.Trailing.Date = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.monthCalendar1.Month.Colors.Trailing.Text = System.Drawing.Color.Red;
            this.monthCalendar1.Month.Colors.Weekend.Date = System.Drawing.Color.DarkRed;
            this.monthCalendar1.Month.DateAlign = TX.Framework.WindowUI.Controls.mcItemAlign.TopCenter;
            this.monthCalendar1.Month.DateFont = new System.Drawing.Font("Tahoma", 14.25F);
            this.monthCalendar1.Month.ShowMonthInDay = true;
            this.monthCalendar1.Month.TextAlign = TX.Framework.WindowUI.Controls.mcItemAlign.BottomCenter;
            this.monthCalendar1.Month.TextFont = new System.Drawing.Font("Tahoma", 9.75F);
            this.monthCalendar1.Month.Transparency.Background = 190;
            this.monthCalendar1.Month.Transparency.Text = 200;
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.ShowFooter = false;
            this.monthCalendar1.Size = new System.Drawing.Size(564, 280);
            this.monthCalendar1.TabIndex = 0;
            this.monthCalendar1.Weekdays.BackColor1 = System.Drawing.Color.Transparent;
            this.monthCalendar1.Weekdays.BackColor2 = System.Drawing.Color.SeaShell;
            this.monthCalendar1.Weekdays.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(168)))), ((int)(((byte)(192)))));
            this.monthCalendar1.Weekdays.Font = new System.Drawing.Font("Tahoma", 11.5F);
            this.monthCalendar1.Weekdays.GradientMode = TX.Framework.WindowUI.Controls.mcGradientMode.Vertical;
            this.monthCalendar1.Weekdays.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(65)))), ((int)(((byte)(0)))));
            this.monthCalendar1.Weeknumbers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            // 
            // txGroupBox2
            // 
            this.txGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.txGroupBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txGroupBox2.CaptionColor = System.Drawing.Color.Black;
            this.txGroupBox2.CaptionFont = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold);
            this.txGroupBox2.Controls.Add(this.txDateTimePicker2);
            this.txGroupBox2.CornerRadius = 0;
            this.txGroupBox2.Location = new System.Drawing.Point(334, 240);
            this.txGroupBox2.Name = "txGroupBox2";
            this.txGroupBox2.Size = new System.Drawing.Size(270, 70);
            this.txGroupBox2.TabIndex = 16;
            this.txGroupBox2.TabStop = false;
            this.txGroupBox2.Text = "分组1";
            this.txGroupBox2.TextMargin = 6;
            // 
            // txDateTimePicker2
            // 
            this.txDateTimePicker2.CalendarForeColor = System.Drawing.Color.Blue;
            this.txDateTimePicker2.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(247)))), ((int)(((byte)(250)))));
            this.txDateTimePicker2.CalendarTitleBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(74)))), ((int)(((byte)(181)))), ((int)(((byte)(237)))));
            this.txDateTimePicker2.CalendarTrailingForeColor = System.Drawing.Color.CadetBlue;
            this.txDateTimePicker2.Location = new System.Drawing.Point(7, 20);
            this.txDateTimePicker2.Name = "txDateTimePicker2";
            this.txDateTimePicker2.ShowCheckBox = true;
            this.txDateTimePicker2.Size = new System.Drawing.Size(132, 21);
            this.txDateTimePicker2.TabIndex = 0;
            this.txDateTimePicker2.Value = new System.DateTime(2015, 8, 9, 16, 8, 2, 250);
            // 
            // winMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CaptionHeight = 34;
            this.ClientSize = new System.Drawing.Size(978, 602);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Location = new System.Drawing.Point(0, 0);
            this.MainMenuStrip = this.txMenuStrip1;
            this.Name = "winMain";
            this.Padding = new System.Windows.Forms.Padding(5, 8, 5, 5);
            this.Text = "主窗体-**ERP系统";
            this.Load += new System.EventHandler(this.winMain_Load);
            this.panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.xPanderPanelList1.ResumeLayout(false);
            this.xPanderPanel1.ResumeLayout(false);
            this.txTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.txGroupBox1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.txMenuStrip2.ResumeLayout(false);
            this.txMenuStrip2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.txGroupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private TX.Framework.WindowUI.Controls.XPanderPanelList xPanderPanelList1;
        private TX.Framework.WindowUI.Controls.XPanderPanel xPanderPanel1;
        private TX.Framework.WindowUI.Controls.XPanderPanel xPanderPanel2;
        private TX.Framework.WindowUI.Controls.XPanderPanel xPanderPanel3;
        private TX.Framework.WindowUI.Controls.XPanderPanel xPanderPanel4;
        private TX.Framework.WindowUI.Controls.TXTabControl txTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private TX.Framework.WindowUI.Controls.TXButton txButton4;
        private TX.Framework.WindowUI.Controls.TXButton txButton3;
        private TX.Framework.WindowUI.Controls.TXButton txButton2;
        private TX.Framework.WindowUI.Controls.TXButton txButton1;
        private TX.Framework.WindowUI.Controls.TXButton txButton7;
        private TX.Framework.WindowUI.Controls.TXButton txButton6;
        private TX.Framework.WindowUI.Controls.TXButton txButton5;
        private TX.Framework.WindowUI.Controls.TXButton txButton8;
        private System.Windows.Forms.TabPage tabPage2;
        private TX.Framework.WindowUI.Controls.Docking.DockPanel dockPanel1;
        private TX.Framework.WindowUI.Controls.Panel panel2;
        private TX.Framework.WindowUI.Controls.Panel panel4;
        private TX.Framework.WindowUI.Controls.Panel panel3;
        private System.Windows.Forms.TabPage tabPage3;
        private TX.Framework.WindowUI.Controls.TXTreeComboBox txTreeComboBox1;
        private TX.Framework.WindowUI.Controls.MultiselectComboBox multiselectComboBox1;
        private System.Windows.Forms.TabPage tabPage4;
        private TX.Framework.WindowUI.Controls.TXButton txButton9;
        private TX.Framework.WindowUI.Controls.TreeListView treeListView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.TabPage tabPage5;
        private TX.Framework.WindowUI.Controls.TXRadioButton txRadioButton2;
        private TX.Framework.WindowUI.Controls.TXRadioButton txRadioButton1;
        private TX.Framework.WindowUI.Controls.TXCheckBox txCheckBox2;
        private TX.Framework.WindowUI.Controls.TXComboBox txComboBox1;
        private TX.Framework.WindowUI.Controls.TXCheckBox txCheckBox1;
        private TX.Framework.WindowUI.Controls.TXGroupBox txGroupBox1;
        private TX.Framework.WindowUI.Controls.TXDateTimePicker txDateTimePicker1;
        private TX.Framework.WindowUI.Controls.TXHtmlEditor txHtmlEditor1;
        private TX.Framework.WindowUI.Controls.MonthCalendar monthCalendar1;
        private TX.Framework.WindowUI.Controls.TXButton txButton10;
        private TX.Framework.WindowUI.Controls.TXTextBox txTextBox1;
        private TX.Framework.WindowUI.Controls.TXRangeValue txRangeValue1;
        private TX.Framework.WindowUI.Controls.TXTextBox txTextBox2;
        private TX.Framework.WindowUI.Controls.TXTreeComboBox txTreeComboBox2;
        private TX.Framework.WindowUI.Controls.TXMenuStrip txMenuStrip1;
        private TX.Framework.WindowUI.Controls.TXMenuStrip txMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem 右键菜单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 好好学习ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 天天向上ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 菜单2ToolStripMenuItem;
        private TX.Framework.WindowUI.Controls.TXGroupBox txGroupBox2;
        private TX.Framework.WindowUI.Controls.TXDateTimePicker txDateTimePicker2;

    }
}

