﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TX.Framework.WindowUI
{
    internal enum EnumTheme
    {
        Default = 0,

        BlueSea = 1,

        KissOfAngel = 2,

        NoFlower = 3,

        SunsetRed = 4,
    }
}
