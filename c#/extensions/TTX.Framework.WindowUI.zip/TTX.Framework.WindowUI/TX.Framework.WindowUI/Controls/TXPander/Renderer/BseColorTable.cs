﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TX.Framework.WindowUI.Controls
{
    /// <summary>
    /// Baseclass for a colortable for the <see cref="BseRenderer"/>
    /// </summary>
    public class BseColorTable : TX.Framework.WindowUI.Controls.ProfessionalColorTable
    {
    }
}
