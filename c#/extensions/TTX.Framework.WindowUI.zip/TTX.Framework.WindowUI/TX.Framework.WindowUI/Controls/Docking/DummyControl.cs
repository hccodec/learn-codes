using System;
using System.Windows.Forms;

namespace TX.Framework.WindowUI.Controls.Docking
{
	internal class DummyControl : Control
	{
		public DummyControl()
		{
			SetStyle(ControlStyles.Selectable, false);
		}
	}
}
