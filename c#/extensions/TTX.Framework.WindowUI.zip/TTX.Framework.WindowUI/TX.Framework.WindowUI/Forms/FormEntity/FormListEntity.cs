﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TX.Framework.WindowUI.Forms
{
    public partial class FormListEntity : BaseForm
    {
        public FormListEntity()
        {
            InitializeComponent();
            this.ShowInTaskbar = false;
        }
    }
}
