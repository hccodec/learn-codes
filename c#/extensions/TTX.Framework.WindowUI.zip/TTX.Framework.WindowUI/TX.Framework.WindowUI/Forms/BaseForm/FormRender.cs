﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TX.Framework.WindowUI.Forms
{
    /// <summary>
    /// 窗体的基本绘制处理类
    /// </summary>
    /// User:Ryan  CreateTime:2012-8-3 16:26.
    internal  class FormRender
    {
       // public void Draw
    }
}
