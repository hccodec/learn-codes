# XAML basics: create a user interface - sample code

This sample represents the starting point for [XAML basics: create a user interface](https://docs.microsoft.com/windows/uwp/get-started/xaml-basics-ui).

