# XAML basics: create custom styles - sample code

This sample represents the starting point for [XAML basics: create custom styles](https://docs.microsoft.com/windows/uwp/get-started/xaml-basics-style).

